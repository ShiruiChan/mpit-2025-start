# autobid_utils_robust.py
# -*- coding: utf-8 -*-

import os
import json
from typing import Dict, Any, List, Optional

import numpy as np
import pandas as pd

import warnings
warnings.filterwarnings("ignore", category=FutureWarning, module="pandas")

try:
    import joblib
except Exception:
    joblib = None

try:
    from catboost import CatBoostClassifier
except Exception:
    CatBoostClassifier = None

VERY_VERBOSE = os.environ.get("AUTOBID_VERY_VERBOSE", "0") in ("1", "true", "True")

def _log(msg: str) -> None:
    """Light logger; prints only when VERY_VERBOSE=1."""
    if VERY_VERBOSE:
        print(f"[autobid] {msg}")


_ID_COLS = ["order_id", "tender_id", "driver_id", "user_id"]

def _ensure_str_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Force all column names to str."""
    if not all(isinstance(c, str) for c in df.columns):
        df = df.rename(columns=lambda c: str(c))
    return df

def _ensure_float64_column(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Guarantee df[col] exists and is float64 (separate block, no int casts)."""
    if col not in df.columns:
        df.insert(len(df.columns), col, np.nan)
    df.loc[:, col] = pd.to_numeric(df[col], errors="coerce").astype("float64")
    return df

def load_artifacts(
    model_path: str = "autobid_catboost.cbm",
    fns_path: str = "cb_feature_names.json",
    calibrator_path: str = "autobid_isotonic.joblib",
    te_maps_path: str = "cb_te_maps.json",
):
    """Load CatBoost model + feature names + optional calibrator + TE maps."""
    if CatBoostClassifier is None:
        raise RuntimeError("catboost is not installed")

    model = CatBoostClassifier()
    model.load_model(model_path)
    _log(f"Loaded CatBoost model: {model_path}")

    with open(fns_path, "r", encoding="utf-8") as f:
        fns = json.load(f)
    # normalize feature name lists
    fns["num"] = [str(c) for c in fns.get("num", []) if c is not None and str(c) != ""]
    fns["cat"] = [str(c) for c in fns.get("cat", []) if c is not None and str(c) != ""]
    _log(f"Feature names: num={len(fns['num'])}, cat={len(fns['cat'])}")

    calibrator = None
    if joblib is not None:
        try:
            calibrator = joblib.load(calibrator_path)
            _log(f"Loaded calibrator: {calibrator_path}")
        except Exception:
            _log("Calibrator not found/disabled.")

    # TE maps: dict[col] -> dict[value] = score; supports optional "__default__"
    try:
        with open(te_maps_path, "r", encoding="utf-8") as f:
            te_maps = json.load(f)
            # allow list of pairs -> dict
            if isinstance(te_maps, list):
                te_maps = dict(te_maps)
            # only keep per-column dicts
            te_maps = {str(k): v for k, v in te_maps.items() if isinstance(v, dict)}
    except Exception:
        te_maps = {}
    _log(f"TE-maps loaded for {len(te_maps)} column(s)")

    return model, fns, calibrator, te_maps

def apply_te_maps(df: pd.DataFrame, te_maps: Dict[str, Dict[Any, float]], prior: float = 0.5) -> pd.DataFrame:
    """Apply per-column TE maps. Falls back to mapping['__default__'] or prior."""
    if not te_maps:
        return df

    out = _ensure_str_columns(df.copy())

    # built-in TE for id columns if a mapping provided
    for col, mapping in te_maps.items():
        if col not in out.columns:
            continue

        ser = out[col]
        # try direct map first (no astype(str) to keep perf & proper keys)
        mapped = ser.map(mapping)

        # default
        default_val = mapping.get("__default__", prior) if isinstance(mapping, dict) else prior
        mapped = pd.to_numeric(mapped, errors="coerce").fillna(default_val)

        out.loc[:, col] = mapped.astype("float64")

    # Also add TE for known ID columns if a single flat mapping dict was provided
    # (backward compat: when te_maps mistakenly was a flat dict of ids->score)
    if all(not isinstance(v, dict) for v in te_maps.values()) and len(te_maps) > 0:
        # legacy path; interpret te_maps as one big mapping for all IDs
        legacy_map = te_maps  # type: ignore
        for idc in [c for c in _ID_COLS if c in out.columns]:
            te_col = f"te_{idc}"
            mapped = out[idc].map(legacy_map)
            mapped = pd.to_numeric(mapped, errors="coerce").fillna(prior)
            out.loc[:, te_col] = mapped.astype("float64")

    return out

def _coerce_dtypes_for_infer(df: pd.DataFrame, fns: Dict[str, List[str]]) -> pd.DataFrame:
    """Return X with columns ordered as [cat..., num...], dtypes object/float64."""
    out = _ensure_str_columns(df.copy())

    num_cols = [str(c) for c in fns.get("num", []) if c is not None and str(c) != ""]
    cat_cols = [str(c) for c in fns.get("cat", []) if c is not None and str(c) != ""]

    # ensure presence
    for c in num_cols:
        if c not in out.columns:
            out.loc[:, c] = 0.0
    for c in cat_cols:
        if c not in out.columns:
            out.loc[:, c] = ""

    # cast
    for c in num_cols:
        arr = pd.to_numeric(np.asarray(out[c]), errors="coerce")
        out.loc[:, c] = np.nan_to_num(arr, nan=0.0).astype("float64")

    for c in cat_cols:
        # leave as strings/objects for CatBoost
        out.loc[:, c] = out[c].astype("object")

    ordered = cat_cols + num_cols
    return out[ordered]


def build_features_df(df_row_like, te_maps: Dict[str, Dict[Any, float]]) -> pd.DataFrame:
    if isinstance(df_row_like, pd.DataFrame):
        df = df_row_like.copy()
    elif isinstance(df_row_like, pd.Series):
        df = df_row_like.to_frame().T
    elif isinstance(df_row_like, dict):
        df = pd.DataFrame([df_row_like])
    else:
        # на всякий случай
        df = pd.DataFrame([pd.Series(df_row_like)])

    df = _ensure_str_columns(df).reset_index(drop=True)

    for c in df.columns:
        v = df.at[0, c]
        if isinstance(v, (list, tuple, np.ndarray, pd.Series)):
            df.at[0, c] = (v[0] if len(v) > 0 else np.nan)

    if "order_timestamp" in df.columns:
        df.loc[:, "order_timestamp"] = pd.to_datetime(df["order_timestamp"], errors="coerce")
        df.loc[:, "order_hour"] = df["order_timestamp"].dt.hour
        df.loc[:, "order_dow"] = df["order_timestamp"].dt.dayofweek

    for c in ("price_bid_local", "price_start_local", "delta_bid_vs_start",
              "ratio_bid_to_start", "bid_uplift_abs"):
        if c in df.columns:
            df.loc[:, c] = pd.to_numeric(np.asarray(df[c]), errors="coerce").astype("float64")

    df = apply_te_maps(df, te_maps, prior=0.5)
    return df

def predict_accept_prob(df_features: pd.DataFrame, model, fns, calibrator=None) -> np.ndarray:
    """Predict acceptance probability для DataFrame с учётом категориальных колонок через Pool."""
    X = _coerce_dtypes_for_infer(df_features, fns)

    # индексы категориальных фич в X (строки/object)
    cat_cols = [c for c in fns.get("cat", []) if c in X.columns]
    cat_idx = [X.columns.get_loc(c) for c in cat_cols]

    # подаём в CatBoost через Pool, чтобы не было ошибок типов
    pool = Pool(X, cat_features=cat_idx)
    p = model.predict_proba(pool)[:, 1]

    p = np.asarray(p, dtype="float64")
    if calibrator is not None:
        p = calibrator.transform(p)
        p = np.asarray(p, dtype="float64")
    # защита от NaN/Inf
    p = np.clip(np.nan_to_num(p, nan=0.0, posinf=1.0, neginf=0.0), 0.0, 1.0)
    return p


def recommend_bid_for_row(
    row: pd.Series,
    model,
    fns,
    calibrator=None,
    te_maps: Optional[Dict[str, Dict[Any, float]]] = None,
    k_min: float = 0.75,
    k_max: float = 1.60,
    k_step: float = 0.025,
) -> Dict[str, Any]:
    """
    Подбирает цену, максимизирующую ER = price * P(accept | price, features) для одной заявки.

    Возвращает dict: {"price": float, "p_accept": float, "er": float}
    """
    te_maps = te_maps or {}

    # 1) базовые фичи (одна строка)
    base = build_features_df(pd.DataFrame([row]), te_maps)
    base = base.reset_index(drop=True)

    # 2) определяем стартовую цену
    idx0 = 0
    start = None
    if "price_start_local" in base.columns and pd.notna(base.at[idx0, "price_start_local"]):
        start = float(base.at[idx0, "price_start_local"])
    elif "price_bid_local" in base.columns and pd.notna(base.at[idx0, "price_bid_local"]):
        start = float(base.at[idx0, "price_bid_local"])
    else:
        start = 0.0
        base = _ensure_float64_column(base, "price_start_local")
        base.at[idx0, "price_start_local"] = 0.0

    if not np.isfinite(start) or start <= 0:
        # дефолт: ничего не можем — возвращаем нули
        return {"price": float(start), "p_accept": 0.0, "er": 0.0}

    _log(f"Row start price: {start}")

    # 3) сетка коэффициентов и цен
    ks = np.arange(k_min, k_max + 1e-9, k_step, dtype="float64")
    prices = (start * ks).astype("float64")

    # 4) размножаем базу под все цены (векторно)
    f = pd.concat([base.iloc[[0]].copy() for _ in range(len(prices))], ignore_index=True)

    # строго приводим числовые столбцы, где изменяем значения
    for c in ("price_bid_local", "price_start_local", "delta_bid_vs_start", "ratio_bid_to_start", "bid_uplift_abs"):
        if c in f.columns:
            f.loc[:, c] = pd.to_numeric(f[c], errors="coerce").astype("float64")

    f.loc[:, "price_bid_local"] = prices
    if "delta_bid_vs_start" in f.columns:
        f.loc[:, "delta_bid_vs_start"] = prices - float(start)
    if "ratio_bid_to_start" in f.columns:
        # защищаемся от деления на ноль (хотя выше уже вернули бы нули)
        denom = float(start) if start != 0 else np.nan
        f.loc[:, "ratio_bid_to_start"] = prices / denom
    if "bid_uplift_abs" in f.columns:
        f.loc[:, "bid_uplift_abs"] = prices - float(start)

    # 5) батч-предикт
    probs = predict_accept_prob(f, model, fns, calibrator)   # (len(prices),)
    probs = np.clip(probs, 0.0, 1.0)

    # 6) ER и выбор максимума
    er = prices * probs
    if not np.any(np.isfinite(er)):
        return {"price": float(start), "p_accept": 0.0, "er": 0.0}

    k = int(np.nanargmax(er))
    best_price = float(prices[k])
    best_p = float(probs[k])
    best_er = float(er[k])

    return {"price": best_price, "p_accept": best_p, "er": best_er}
