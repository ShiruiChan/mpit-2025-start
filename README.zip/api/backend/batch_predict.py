#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
batch_predict.py — batch-рекоммендер ставок для кейса Drivee.

Фичи:
- Подробные логи (--very-verbose или AUTOBID_VERY_VERBOSE=1)
- Безопасные предсказания с fallback-кривой P(accept | ratio, hour) из test.csv
- Диагностика по каждой строке в *.diagnostics.csv
- Прогрессбар (tqdm) при наличии, либо компактный прогресс

Примеры:
  python batch_predict.py test.csv predictions.csv --test test.csv --very-verbose --debug-first
  python batch_predict.py test.csv predictions.csv \
      --model autobid_catboost.cbm \
      --features cb_feature_names.json \
      --calibrator autobid_isotonic.joblib \
      --te-maps cb_te_maps.json
"""

import os
import sys
import argparse
import math
import pandas as pd
import numpy as np

# Вспомогательные утилиты и модельные артефакты
import autobid_utils_robust as utils
from autobid_utils_robust import load_artifacts, recommend_bid_for_row, _log  # noqa: F401


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="batch_predict.py", description="Batch recommend bids for Drivee case")
    p.add_argument("input", help="Входной CSV (минимум order_id и фичи, необходимые recommend_bid_for_row)")
    p.add_argument("output", help="Путь для сохранения результата predictions.csv")
    p.add_argument("--model", default="autobid_catboost.cbm", help="Путь к .cbm модели CatBoost")
    p.add_argument("--features", default="cb_feature_names.json", help="JSON с порядком/названиями фич модели")
    p.add_argument("--calibrator", default="autobid_isotonic.joblib", help="Isotonic/Platt калибровщик")
    p.add_argument("--te-maps", default="cb_te_maps.json", help="JSON с картами target-encoding/категориальных маппингов")
    p.add_argument("--test", default=None, help="(опц.) test.csv для фолбэка P(accept|ratio,hour)")
    p.add_argument("--debug-first", action="store_true", help="Печатать дебаг по первой успешной строке")
    p.add_argument("--very-verbose", action="store_true", help="Включить подробные логи (равно AUTOBID_VERY_VERBOSE=1)")
    return p.parse_args(argv)


# ====== ЭМПИРИЧЕСКИЙ ФОЛБЭК: P(accept | ratio, hour) =================================
class EmpiricalFallback:
    def __init__(self, test_df: pd.DataFrame):
        df = test_df.copy()
        # бинарная цель
        df["target"] = (df["is_done"].astype(str).str.lower() == "done").astype(int)

        # час
        df["order_timestamp"] = pd.to_datetime(df.get("order_timestamp"), errors="coerce")
        df["order_hour"] = df["order_timestamp"].dt.hour

        # ratio = bid/start
        denom = pd.to_numeric(df.get("price_start_local"), errors="coerce").replace(0, np.nan)
        ratio = pd.to_numeric(df.get("price_bid_local"), errors="coerce") / denom
        df["ratio"] = ratio.clip(0.9, 1.6)

        # биннинг по ratio
        self.bin_edges = np.linspace(0.9, 1.6, 15)  # 14 бинов
        self.bin_centers = (self.bin_edges[:-1] + self.bin_edges[1:]) / 2
        df["rbin"] = pd.cut(df["ratio"], bins=self.bin_edges, include_lowest=True, labels=False)

        # глобальная кривая
        glob = (
            df.dropna(subset=["rbin"])
              .groupby("rbin")["target"].agg(["mean", "count"])
              .reindex(range(len(self.bin_centers)))
        )
        global_mean = float(df["target"].mean()) if len(df) else 0.5
        self.global_p = glob["mean"].fillna(global_mean).to_numpy()

        # почасовые матрицы
        B = len(self.bin_centers)
        self.p_hour = np.tile(self.global_p.reshape(1, B), (24, 1))
        self.cnt_hour = np.zeros((24, B), dtype=float)

        hourly = (
            df.dropna(subset=["rbin", "order_hour"])
              .groupby(["order_hour", "rbin"])["target"]
              .agg(["mean", "count"])
              .reset_index()
        )
        for _, r in hourly.iterrows():
            h = int(r["order_hour"]); b = int(r["rbin"])
            if 0 <= h < 24 and 0 <= b < B:
                self.p_hour[h, b] = float(r["mean"])
                self.cnt_hour[h, b] = float(r["count"])

        # сглаживание редких ячеек
        mask_low = self.cnt_hour < 30
        self.p_hour = np.where(mask_low, 0.5 * self.p_hour + 0.5 * self.global_p.reshape(1, -1), self.p_hour)

    def recommend(self, row: pd.Series):
        try:
            start = float(row.get("price_start_local", np.nan))
            if not np.isfinite(start) or start <= 0:
                return None
            hour = row.get("order_hour", np.nan)
            if pd.isna(hour):
                ts = pd.to_datetime(row.get("order_timestamp", pd.NaT), errors="coerce")
                hour = int(ts.hour) if pd.notna(ts) else 12
            hour = int(max(0, min(23, hour)))

            ratios = self.bin_centers
            prices = start * ratios
            probs = self.p_hour[hour]
            er = prices * probs
            k = int(np.nanargmax(er))
            return {"price": float(prices[k]), "p_accept": float(probs[k]), "er": float(er[k])}
        except Exception:
            return None


def main(argv=None) -> int:
    args = parse_args(argv)

    # Включаем подробные логи при флаге
    if args.very_verbose:
        os.environ["AUTOBID_VERY_VERBOSE"] = "1"

    inp, outp = args.input, args.output
    if not os.path.exists(inp):
        print(f"[batch] Input not found: {inp}", file=sys.stderr)
        return 2

    _log(f"Reading input CSV: {inp}")
    try:
        df = pd.read_csv(inp)
    except Exception as e:
        print(f"[batch] Failed to read CSV: {e}", file=sys.stderr)
        return 2
    _log(f"Input shape: {df.shape}")

    # Мини-валидация важных полей
    must_have_any = ["order_id"]
    missing = [c for c in must_have_any if c not in df.columns]
    if missing:
        print(f"[batch] Missing required columns: {missing}", file=sys.stderr)
        return 2

    # 1) Загрузка артефактов модели
    try:
        model, fns, calibrator, te_maps = load_artifacts(
            args.model, args.features, args.calibrator, args.te_maps
        )
        _log("Artifacts loaded OK")
    except Exception as e:
        print(f"[batch] Failed to load artifacts: {e}", file=sys.stderr)
        return 2

    # 2) Фолбэк по test (если дан)
    fallback = None
    if args.test:
        if os.path.exists(args.test):
            _log(f"Loading test for fallback: {args.test}")
            try:
                test_df = pd.read_csv(args.test)
                fallback = EmpiricalFallback(test_df)
            except Exception as e:
                print(f"[batch] Failed to prepare fallback from test: {e}", file=sys.stderr)
        else:
            _log(f"WARNING: test not found: {args.test} (fallback disabled)")

    # 3) Расчёт
    _log("Predicting bids with DataFrame.apply ...")

    def safe_recommend(row: pd.Series) -> pd.Series:
        try:
            rec = recommend_bid_for_row(row.to_dict(), model, fns, calibrator, te_maps)
            if args.debug_first:
                # однократный «первый удачный» принт
                if not getattr(safe_recommend, "_printed", False):
                    print(f"[debug] first ok row: price={rec['price']:.2f}, p={rec['p_accept']:.4f}, er={rec['er']:.2f}")
                    safe_recommend._printed = True  # type: ignore
            return pd.Series({
                "recommended_price_bid_local": rec["price"],
                "p_accept": rec["p_accept"],
                "expected_revenue": rec["er"],
                "mode": "model",
                "error": None
            })
        except Exception as e:
            if fallback is not None:
                fb = fallback.recommend(row)
                if fb is not None:
                    return pd.Series({
                        "recommended_price_bid_local": fb["price"],
                        "p_accept": fb["p_accept"],
                        "expected_revenue": fb["er"],
                        "mode": "fallback_ok",
                        "error": str(e)
                    })
            return pd.Series({
                "recommended_price_bid_local": np.nan,
                "p_accept": np.nan,
                "expected_revenue": np.nan,
                "mode": "fail",
                "error": str(e)
            })

    # Прогресс: tqdm если доступен, иначе тихо .apply
    results = None
    try:
        from tqdm import tqdm  # type: ignore
        tqdm.pandas(desc="Predict", ncols=80, leave=False)
        results = df.progress_apply(safe_recommend, axis=1)
    except Exception:
        results = df.apply(safe_recommend, axis=1)

    df_out = pd.concat([df.reset_index(drop=True), results.reset_index(drop=True)], axis=1)

    # 4) Сохранение основного результата
    out_cols = ["order_id", "recommended_price_bid_local", "p_accept", "expected_revenue"]
    for c in out_cols:
        if c not in df_out.columns:
            df_out[c] = np.nan
    out_df = df_out[out_cols]

    out_dir = os.path.dirname(os.path.abspath(outp)) or "."
    os.makedirs(out_dir, exist_ok=True)
    out_df.to_csv(outp, index=False)
    print(f"[batch] Saved predictions to: {outp}")

    # 5) Диагностика
    diag_path = os.path.splitext(outp)[0] + ".diagnostics.csv"
    diag_cols = ["order_id", "mode", "error"]
    for c in diag_cols:
        if c not in df_out.columns:
            df_out[c] = np.nan
    df_out[diag_cols].to_csv(diag_path, index=False)
    print(f"[batch] Saved diagnostics to: {diag_path}")

    # Краткая сводка
    mode_counts = df_out["mode"].value_counts(dropna=False).to_dict()
    total = len(df_out)
    ok = int((df_out["mode"] == "model").sum())
    fb = int((df_out["mode"] == "fallback_ok").sum())
    fail = int((df_out["mode"] == "fail").sum())
    print(f"[batch] Summary — total: {total}, model: {ok}, fallback: {fb}, fail: {fail}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
